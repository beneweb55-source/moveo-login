import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import * as jose from 'jose';
import pool from '@/lib/db';
import { Pool } from 'pg';

const scraperPool = new Pool({
  connectionString: process.env.SCRAPER_DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || 'fallback_secret_key_for_development_only'
);

export async function POST(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('auth_token')?.value;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    let userId;
    try {
      const { payload } = await jose.jwtVerify(token, JWT_SECRET);
      userId = payload.userId;
    } catch (err) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { tmdb_id, title, year, type, season, episode } = await request.json();

    if (!tmdb_id) {
      return NextResponse.json({ error: 'Missing tmdb_id' }, { status: 400 });
    }

    // Check if already in catalogue
    if (type === 'tv' && season && episode) {
      const seriesRes = await scraperPool.query(
        'SELECT voe_url FROM series_catalogue WHERE series_tmdb_id = $1 AND season = $2 AND episode = $3 LIMIT 1',
        [tmdb_id, season, episode]
      );
      if (seriesRes.rows.length > 0 && seriesRes.rows[0].voe_url) {
        return NextResponse.json({ status: 'already_available' });
      }

      const animeRes = await scraperPool.query(
        'SELECT voe_url FROM anime_catalogue WHERE series_tmdb_id = $1 AND season = $2 AND episode = $3 LIMIT 1',
        [tmdb_id, season, episode]
      );
      if (animeRes.rows.length > 0 && animeRes.rows[0].voe_url) {
        return NextResponse.json({ status: 'already_available' });
      }
    } else {
      const catalogueRes = await pool.query(
        'SELECT voe_url FROM catalogue WHERE tmdb_id = $1 LIMIT 1',
        [tmdb_id]
      );

      if (catalogueRes.rows.length > 0 && catalogueRes.rows[0].voe_url) {
        return NextResponse.json({ status: 'already_available' });
      }
    }

    // Check if already requested
    const requestRes = await pool.query(
      `SELECT status FROM content_requests 
       WHERE tmdb_id = $1 AND type = $2 
       AND (season IS NULL OR season = $3) 
       AND (episode IS NULL OR episode = $4)
       LIMIT 1`,
      [tmdb_id, type || 'movie', season || null, episode || null]
    );

    if (requestRes.rows.length > 0) {
      return NextResponse.json({ status: 'already_requested' });
    }

    // Insert new request
    await pool.query(
      `INSERT INTO content_requests (tmdb_id, title, year, type, season, episode, requested_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [tmdb_id, title, year, type || 'movie', season || null, episode || null, userId]
    );

    return NextResponse.json({ status: 'requested' });
  } catch (error) {
    console.error('Error in film-request:', error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
